import { GithubUser } from "./GithubUser.js";

// Classe para manipulação de dados:
class Favorites {
  constructor(root) {
    root = document.querySelector(root);

    this.load();
  }

  //metodo reponsavavel por carregar os dados guardados no localStorage ou adicionar o array vazio as entradas
  load() {
    this.entries = JSON.parse(localStorage.getItem("@github-favorites:")) || [];
    if (this.entries.length === 0) {
      document.querySelector("#noFavoritesScreen").style.display = "flex";
    }
  }

  //metodo que salva as entradas do array no localStorage, para que seja possivel sempre carrega-los na pagina.
  save() {
    localStorage.setItem("@github-favorites:", JSON.stringify(this.entries));
  }

  // metodo responsavel por adicionar um novo usuario ao array de entradas.
  async add(userName) {
    try {
      const user = await GithubUser.search(userName);
      const userExist = this.entries.find(
        (entry) => entry.login === user.login
      );

      if (userExist) {
        throw new Error("Usuário já favoritado!");
      }

      if (user.login === undefined) {
        throw new Error("usuario não encontrado!");
      }
      this.entries = [user, ...this.entries];
      document.querySelector("#noFavoritesScreen").style.display = "none"; //remove a tela de quando não há nenhum favorito

      this.update(); //atualiza as entradas da tabela sempre que um novo usuario é favoritado
      this.save(); //salva as novas entradas no localStorage
    } catch (err) {
      alert(err.message);
    }
  }

  delete(user) {
    const entryToDelete = this.entries.filter(
      (entry) => entry.login !== user.login
    );
    console.log(entryToDelete);
    this.entries = entryToDelete;
    this.update();
    this.save();
    this.load();
  }
}

// Classe para a visualização
export class FavoritesView extends Favorites {
  constructor(root) {
    super(root);

    this.tbody = document.querySelector("tbody");

    this.update();
    this.onAdd();
  }

  onAdd() {
    const onAdd = document.querySelector("#search button");

    onAdd.onclick = () => {
      const { value } = document.querySelector("#search input");

      this.add(String(value));
    };
  }

  creatRow() {
    const tr = document.createElement("tr");

    tr.innerHTML = `
  <td class="user">
    <img src="" alt="" />
    <a href="" target="_blank">
      <p></p>
      <span></span>
    </a>
  </td>
  <td class = "reposHTML">
  </td>
  <td class = "followersHTML">
  </td>
  <td>
  <button class="toRemove">Remover</button>
  </td>
    `;

    return tr;
  }

  update() {
    this.removeAllTr();
    this.entries.forEach((user) => {
      const row = this.creatRow();
      row.querySelector(
        ".user img"
      ).src = `https://github.com/${user.login}.png`;

      row.querySelector(".user a").href = `https://github.com/${user.login}`;
      row.querySelector(".user a p").textContent = user.name;
      row.querySelector(".user a span").textContent = "/" + user.login;
      row.querySelector(".reposHTML").textContent = user.public_repos;
      row.querySelector(".followersHTML").textContent = user.followers;
      row.querySelector(".toRemove").onclick = () => {
        const confirmDelete = confirm(
          `Tem certeza que deseja excluir o usuario: ${user.login} dos seus favoritos?`
        );

        if (confirmDelete) {
          this.delete(user);
        }
      };
      this.tbody.append(row);
    });

    document.querySelector("#search input").value = "";
  }

  removeAllTr() {
    this.tbody.querySelectorAll("tr").forEach((tr) => {
      tr.remove();
    });
  }
}
